<template>
  <v-container v-if="house">
    <v-row>
      <v-col>
        <h3>{{ house.아파트 }}</h3>
      </v-col>
    </v-row>
    <v-row class="mb-2 mt-1">
      <v-col>
        <v-img :src="require('@/assets/apt.png')" fluid-grow></v-img>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-alert warning>일련번호 : {{ house.일련번호 }}</v-alert>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-alert warning>아파트 이름 : {{ house.아파트 }} </v-alert>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-alert warning>법정동 : {{ house.법정동 }} </v-alert>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-alert warning>층수 : {{ house.층 }}층</v-alert>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-alert warning
          >거래금액 :
          {{
            (parseInt(house.거래금액.replace(",", "")) * 10000) | price
          }}원</v-alert
        >
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "HouseDetail",
  filters: {
    price(value) {
      if (!value) return value;
      return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    },
  },
  computed: {
    ...mapState("house", ["house"]),
    // house() {
    //   return this.$store.state.house;
    // },
  },
};
</script>

<style></style>
