<template>
  <v-container v-if="houses && houses.length != 0" class="text-center">
    <house-list-item
      v-for="(house, index) in houses"
      :key="index"
      :house="house"
    />
  </v-container>
  <v-container v-else class="text-center">
    <v-row>
      <v-col><v-alert warning>주택 목록이 없습니다.</v-alert></v-col>
    </v-row>
  </v-container>
</template>

<script>
import HouseListItem from "@/components/house/HouseListItem.vue";
import { mapState } from "vuex";

export default {
  name: "HouseList",
  components: {
    HouseListItem,
  },
  data() {
    return {};
  },
  computed: {
    ...mapState("house", ["houses"]),
    // houses() {
    //   return this.$store.state.houses;
    // },
  },
};
</script>

<style></style>
