<template>
  <v-row
    class="m-2"
    :class="{ 'mouse-over-bgcolor': isColor }"
    @click="selectHouse"
    @mouseover="colorChange(true)"
    @mouseout="colorChange(false)"
  >
    <v-col cols="2" class="text-center align-self-center">
      <v-img
        thumbnail
        src="https://picsum.photos/250/250/?image=58"
        alt="Image 1"
      ></v-img>
    </v-col>
    <v-col cols="10" class="align-self-center">
      [{{ house.일련번호 }}] {{ house.아파트 }}
    </v-col>
  </v-row>
</template>

<script>
import { mapActions } from "vuex";

export default {
  name: "HouseListItem",
  props: {
    house: Object,
  },
  data() {
    return {
      isColor: false,
    };
  },

  methods: {
    ...mapActions("house", ["detailHouse"]),
    selectHouse() {
      console.log("listRow : ", this.house);
      // this.$store.dispatch("getHouse", this.house);
      this.detailHouse(this.house);
    },
    colorChange(flag) {
      this.isColor = flag;
    },
  },
};
</script>

<style scoped>
.apt {
  width: 50px;
}
.mouse-over-bgcolor {
  background-color: lightblue;
}
</style>
