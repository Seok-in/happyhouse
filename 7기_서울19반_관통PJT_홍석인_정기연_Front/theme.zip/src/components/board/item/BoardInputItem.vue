<template>
  <v-form @submit="onSubmit" @reset="onReset">
    <v-container>
      <v-row>
        <v-col id="userid" class="text-center" sm="2" cols="1">
          작성자 :
        </v-col>
        <v-col cols="2"> {{ article.userid }} </v-col>
      </v-row>
      <v-row id="subject-group">
        <v-col id="subject" class="text-center" sm="2" cols="1"> 제목 : </v-col>
        <v-col cols="2"> <input v-model="article.subject" /> </v-col>
      </v-row>
      <v-row id="content-group">
        <v-col id="content" class="text-center" sm="2" cols="1"> 내용 : </v-col>
        <v-col cols="2" sm="9">
          <v-textarea v-model="article.content"></v-textarea>
        </v-col>
      </v-row>
      <v-row>
        <v-col cols="1" sm="2">
          <button
            v-if="this.type === 'register'"
            class="text-center"
            type="submit"
          >
            등록 완료
          </button>
          <button
            v-if="this.type === 'modify'"
            class="text-center"
            type="submit"
          >
            수정 완료
          </button>
        </v-col>
        <v-col cols="2" sm="2">
          <button type="reset" class="text-center" @click="moveList">
            초기화
          </button>
        </v-col>
      </v-row>
    </v-container>
  </v-form>
</template>

<script>
import http from "@/api/http";
export default {
  name: "BoardInputItem",
  props: {
    type: { type: String },
  },
  data() {
    return {
      article: {
        articleno: 0,
        userid: "",
        subject: "",
        content: "",
      },
      isUserid: false,
    };
  },
  computed: {
    message() {
      if (this.article.content)
        return this.article.content.split("\n").join("<br>");
      return "";
    },
  },
  created() {
    if (this.type === "modify") {
      http.get(`/board/${this.$route.params.articleno}`).then(({ data }) => {
        // this.article.articleno = data.article.articleno;
        // this.article.userid = data.article.userid;
        // this.article.subject = data.article.subject;
        // this.article.content = data.article.content;
        this.article = data;
        console.log("inputitem : ");
        console.log(this.article);
      });
      this.isUserid = true;
    }
  },

  methods: {
    onSubmit(event) {
      event.preventDefault();
      let err = true;
      let msg = "";
      if (!this.article.userid) {
        msg = "작성자 입력해주세요";
        err = false;
        this.$refs.userid.focus();
      }
      if (!this.article.subject) {
        msg = "제목 입력해주세요";
        err = false;
        this.$refs.subject.focus();
      }
      if (!this.article.content) {
        msg = "내용 입력해주세요";
        err = false;
        this.$refs.content.focus();
      }
      if (!err) alert(msg);
      else
        this.type === "register" ? this.registArticle() : this.modifyArticle();
    },
    onReset(event) {
      event.preventDefault();
      this.article.articleno = 0;
      this.article.subject = "";
      this.article.content = "";
      this.$router.push({ name: "boardList" });
    },
    registArticle() {
      http
        .post(`/board`, {
          userid: this.article.userid,
          subject: this.article.subject,
          content: this.article.content,
        })
        .then(({ data }) => {
          let msg = "등록 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "등록이 완료되었습니다.";
          }
          alert(msg);
          this.moveList();
        });
    },
    modifyArticle() {
      http
        .put(`/board/${this.article.articleno}`, {
          articleno: this.article.articleno,
          userid: this.article.userid,
          subject: this.article.subject,
          content: this.article.content,
        })
        .then(({ data }) => {
          let msg = "수정 처리시 문제가 발생했습니다.";
          if (data === "success") {
            msg = "수정이 완료되었습니다.";
          }
          alert(msg);
          // 현재 route를 /list로 변경.
          this.$router.push({ name: "boardList" });
        });
    },
    moveList() {
      this.$router.push({ name: "boardList" });
    },
  },
};
</script>

<style scoped></style>
