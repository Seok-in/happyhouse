<template>
  <v-container>
    <v-row>
      <v-col> 제목 : {{ article.subject }} </v-col>
      <v-col> 작성자 : {{ article.userid }} </v-col>
      <v-col> 조회 수 : {{ article.hit }}</v-col>
    </v-row>
    <v-row>
      <v-col>
        <div>내용 : {{ message }}</div>
      </v-col>
    </v-row>
    <v-row>
      <v-col sm="2" cols="1">
        <button @click="listArticle">목록</button>
      </v-col>
      <v-col sm="2" cols="2">
        <button @click="moveModifyArticle">수정</button>
      </v-col>
      <v-col sm="2" cols="3">
        <button @click="deleteArticle">삭제</button>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
// import moment from "moment";
import http from "@/api/http";

export default {
  name: "BoardDetail",
  data() {
    return {
      article: {},
    };
  },
  computed: {
    message() {
      if (this.article.content)
        return this.article.content.split("\n").join("<br>");
      return "";
    },
  },
  created() {
    http.get(`/board/${this.$route.params.articleno}`).then(({ data }) => {
      this.article = data;
      console.log(data);
    });
  },
  methods: {
    listArticle() {
      this.$router.push({ name: "boardList" });
    },
    moveModifyArticle() {
      this.$router.replace({
        name: "boardModify",
        params: { articleno: this.article.articleno },
      });
      //   this.$router.push({ path: `/board/modify/${this.article.articleno}` });
    },
    deleteArticle() {
      if (confirm("정말로 삭제?")) {
        this.$router.replace({
          name: "boardDelete",
          params: { articleno: this.article.articleno },
        });
      }
    },
  },
  // filters: {
  //   dateFormat(regtime) {
  //     return moment(new Date(regtime)).format("YY.MM.DD hh:mm:ss");
  //   },
  // },
};
</script>

<style></style>
