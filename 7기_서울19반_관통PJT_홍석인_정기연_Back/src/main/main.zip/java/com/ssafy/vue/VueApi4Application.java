package com.ssafy.vue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VueApi4Application {
	public static void main(String[] args) {
		SpringApplication.run(VueApi4Application.class, args);
	}

}
